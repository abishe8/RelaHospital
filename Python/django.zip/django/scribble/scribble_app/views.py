from django.shortcuts import render

# Create your views here.


def home(request):
    context = {}
    return render(request, "D:/Rela Internship/django/scribble/scribble_app/templates/scribble_app/home.html", context)
