from django.apps import AppConfig


class ScribbleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scribble_app'
