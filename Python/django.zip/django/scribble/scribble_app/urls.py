from . import views
from django.urls import path
from scribble_app import views

urlpatterns = [
    path("", views.home, name="Home"),
]
